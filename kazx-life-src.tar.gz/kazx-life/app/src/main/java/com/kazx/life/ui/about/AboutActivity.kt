package com.kazx.life.ui.about

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kazx.life.R
import com.kazx.life.databinding.ActivityAboutBinding
import com.kazx.life.databinding.ItemDeveloperBinding
import com.kazx.life.net.AccentHelper

/**
 * 关于 口中Life：
 *  - 顶部团队 logo + 名称（CollapsingToolbar）
 *  - 三个快捷按钮：鸣谢名单 Activity / 删帖服务 / 学校官方问题
 *  - 鸣谢名单（开发者卡片 + 特别鸣谢网格）
 *  - 开源许可证列表（点击展开全文）
 *  - 出品署名 + 愿友谊长存
 */
class AboutActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAboutBinding

    data class Developer(val name: String, val subtitle: String?, val avatarRes: Int)
    data class ThanksItem(val name: String)

    private val developers = listOf(
        Developer("夏日之瓜", "(季节限定doge)", R.drawable.avatar_dev2),
        Developer("Youutaku", null, R.drawable.avatar_dev3),
        Developer("Accelerator", null, R.drawable.avatar_dev4)
    )

    private val thanks = listOf(
        "快乐", "南京晨跑大学", "宋分题", "章鱼小丸子狂热爱好者",
        "口中万能墙", "德克萨斯做得到", "T–T", "逐梦海天",
        "风掠川暮", "新高一死宅", "zero", "等等......"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
        binding.toolbar.setNavigationIcon(R.drawable.ic_nav_home)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // 三个快捷按钮
        binding.btnThanks.setOnClickListener {
            // 与独立 ThanksActivity 相同，这里直接复用
            startActivity(Intent(this, ThanksActivity::class.java))
        }
        binding.btnDelete.setOnClickListener { openUrl("https://kzbbq.mysxl.cn/2") }
        binding.btnOfficial.setOnClickListener { openUrl("https://kzbbq.mysxl.cn/3") }
        binding.icpBadge.setOnClickListener { openUrl("https://icp.jkun.cf/id.php?keyword=20250620") }

        // 开发者卡片（直接动态 addView）
        val inflater = LayoutInflater.from(this)
        for (dev in developers) {
            val vb = ItemDeveloperBinding.inflate(inflater, binding.developersContainer, false)
            vb.name.text = dev.name
            vb.subtitle.text = dev.subtitle
            vb.subtitle.visibility = if (dev.subtitle.isNullOrBlank()) android.view.View.GONE else android.view.View.VISIBLE
            Glide.with(this).load(dev.avatarRes).circleCrop().into(vb.avatar)
            binding.developersContainer.addView(vb.root)
        }

        // 特别鸣谢 网格（3 列）
        binding.thanksGrid.layoutManager = GridLayoutManager(this, 3)
        binding.thanksGrid.adapter = ThanksGridAdapter(thanks.map { ThanksItem(it) })

        // 开源许可证（可展开卡片）
        binding.licenseList.layoutManager = LinearLayoutManager(this)
        binding.licenseList.adapter = LicenseAdapter(Licenses.all)
    }

    override fun onResume() {
        super.onResume()
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
    }

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "未找到浏览器", Toast.LENGTH_SHORT).show()
        }
    }
}

/** 关于页内嵌的小型鸣谢网格适配器。 */
class ThanksGridAdapter(private val list: List<AboutActivity.ThanksItem>) :
    RecyclerView.Adapter<ThanksGridAdapter.VH>() {

    class VH(val binding: com.kazx.life.databinding.ItemThanksBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = VH(
        com.kazx.life.databinding.ItemThanksBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
    )

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.binding.name.text = list[position].name
    }

    override fun getItemCount(): Int = list.size
}
