package com.kazx.life.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.kazx.life.databinding.ActivityPhotoViewerBinding
import com.kazx.life.databinding.ItemPagerImageBinding

/**
 * 大图查看器：
 *  - 支持多张图片通过 ViewPager2 左右滑动切换
 *  - 每张图独立缩放（双击 / 双指）、拖动
 *  - 单击图片或关闭按钮返回
 */
class PhotoViewerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPhotoViewerBinding
    private lateinit var images: List<String>
    private var initialIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 沉浸式黑底
        window.statusBarColor = android.graphics.Color.BLACK
        binding = ActivityPhotoViewerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        images = intent.getStringArrayListExtra(EXTRA_IMAGES)?.toList().orEmpty()
        initialIndex = intent.getIntExtra(EXTRA_INDEX, 0).coerceIn(0, (images.size - 1).coerceAtLeast(0))

        if (images.isEmpty()) {
            finish()
            return
        }

        binding.viewPager.adapter = PagerAdapter(images) { finish() }
        binding.viewPager.setCurrentItem(initialIndex, false)
        updateIndicator(initialIndex)

        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                updateIndicator(position)
            }
        })

        binding.btnClose.setOnClickListener { finish() }
    }

    private fun updateIndicator(pos: Int) {
        binding.pageIndicator.text = "${pos + 1} / ${images.size}"
    }

    companion object {
        const val EXTRA_IMAGES = "extra_images"
        const val EXTRA_INDEX = "extra_index"
    }
}

private class PagerAdapter(
    private val images: List<String>,
    private val onTap: () -> Unit
) : RecyclerView.Adapter<PagerAdapter.VH>() {

    class VH(val binding: ItemPagerImageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemPagerImageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val url = images[position]
        holder.binding.image.onTap = onTap
        holder.binding.image.resetZoom()
        Glide.with(holder.binding.image.context)
            .load(url)
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .fitCenter()
            .into(holder.binding.image)
    }

    override fun getItemCount(): Int = images.size
}
