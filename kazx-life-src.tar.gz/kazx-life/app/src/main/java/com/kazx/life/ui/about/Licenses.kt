package com.kazx.life.ui.about

/**
 * 开源依赖许可证数据。Apache 2.0 全文较长，这里放摘要与声明。
 */
data class LicenseItem(
    val name: String,
    val version: String,
    val author: String,
    val licenseType: String,
    val licenseUrl: String,
    val notice: String
)

object Licenses {
    val apache2Header = "Licensed under the Apache License, Version 2.0 (the " +
        "\"License\"); you may not use this file except in compliance with the License. " +
        "You may obtain a copy of the License at: http://www.apache.org/licenses/LICENSE-2.0 " +
        "Unless required by applicable law or agreed to in writing, software distributed " +
        "under the License is distributed on an \"AS IS\" BASIS, WITHOUT WARRANTIES OR " +
        "CONDITIONS OF ANY KIND, either express or implied. See the License for the " +
        "specific language governing permissions and limitations under the License."

    val mitHeader = "Permission is hereby granted, free of charge, to any person obtaining " +
        "a copy of this software and associated documentation files (the \"Software\"), to " +
        "deal in the Software without restriction, including without limitation the rights " +
        "to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies " +
        "of the Software, and to permit persons to whom the Software is furnished to do so, " +
        "subject to the following conditions: The above copyright notice and this permission " +
        "notice shall be included in all copies or substantial portions of the Software."

    val all: List<LicenseItem> = listOf(
        LicenseItem(
            name = "OkHttp",
            version = "4.12.0",
            author = "Square, Inc.",
            licenseType = "Apache-2.0",
            licenseUrl = "https://square.github.io/okhttp/",
            notice = apache2Header
        ),
        LicenseItem(
            name = "Kotlin Standard Library + Coroutines",
            version = "1.9.24 / 1.8.0",
            author = "JetBrains s.r.o.",
            licenseType = "Apache-2.0",
            licenseUrl = "https://kotlinlang.org/",
            notice = apache2Header
        ),
        LicenseItem(
            name = "Jsoup",
            version = "1.17.2",
            author = "Jonathan Hedley",
            licenseType = "MIT",
            licenseUrl = "https://jsoup.org/",
            notice = mitHeader
        ),
        LicenseItem(
            name = "Glide",
            version = "4.16.0",
            author = "Sam Judd, Google Inc.",
            licenseType = "BSD-3-Clause",
            licenseUrl = "https://github.com/bumptech/glide",
            notice = "Redistribution and use in source and binary forms, with or without " +
                "modification, are permitted provided that the following conditions are met: " +
                "1. Redistributions of source code must retain the above copyright notice, " +
                "this list of conditions and the following disclaimer. 2. Redistributions " +
                "in binary form must reproduce the above copyright notice, this list of " +
                "conditions and the following disclaimer in the documentation and/or other " +
                "materials provided with the distribution. 3. Neither the name of the " +
                "copyright holder nor the names of its contributors may be used to endorse " +
                "or promote products derived from this software without specific prior " +
                "written permission."
        ),
        LicenseItem(
            name = "AndroidX (AppCompat / Material / RecyclerView / Lifecycle ...)",
            version = "AndroidX",
            author = "The Android Open Source Project",
            licenseType = "Apache-2.0",
            licenseUrl = "https://source.android.com/",
            notice = "Copyright (C) The Android Open Source Project. " + apache2Header
        ),
        LicenseItem(
            name = "Material Components for Android",
            version = "1.12.0",
            author = "Google Inc.",
            licenseType = "Apache-2.0",
            licenseUrl = "https://material.io/develop/android",
            notice = "Copyright 2016 Google Inc. " + apache2Header
        ),
        LicenseItem(
            name = "Gradle Wrapper",
            version = "8.7",
            author = "Gradle Inc.",
            licenseType = "Apache-2.0",
            licenseUrl = "https://gradle.org/",
            notice = "Copyright Gradle Inc. " + apache2Header
        )
    )
}
