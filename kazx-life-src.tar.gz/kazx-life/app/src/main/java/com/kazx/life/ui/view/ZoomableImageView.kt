package com.kazx.life.ui.view

import android.content.Context
import android.graphics.Matrix
import android.graphics.PointF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.appcompat.widget.AppCompatImageView
import kotlin.math.max
import kotlin.math.min

/**
 * 可缩放 ImageView：
 *  - 双击：在 1.0x ~ 2.5x 之间切换
 *  - 双指捏合：0.8x ~ 5.0x 范围缩放
 *  - 放大后可单指拖动（图片不超出边界）
 *  - 单击：通过 onTap 回调告知父组件（一般用于关闭查看器）
 */
class ZoomableImageView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : AppCompatImageView(context, attrs) {

    // 变换矩阵与值
    private val matrixValues = FloatArray(9)
    private val baseMatrix = Matrix()
    private var mode = NONE
    private var saveScale = 1f

    // 缩放/平移手势数据
    private val scaleDetector: ScaleGestureDetector
    private val gestureDetector: GestureDetector
    var onTap: (() -> Unit)? = null

    // 拖拽用
    private val start = PointF()
    private val mid = PointF()
    private var oldDist = 1f
    private var origWidth = 0f
    private var origHeight = 0f
    private var viewWidth = 0
    private var viewHeight = 0

    init {
        scaleType = ScaleType.MATRIX
        scaleDetector = ScaleGestureDetector(context, ScaleListener())
        gestureDetector = GestureDetector(context, GestureListener())
        setOnTouchListener { _, event -> onTouch(event) }
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            mode = ZOOM
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            var mScaleFactor = detector.scaleFactor
            val origScale = saveScale
            saveScale *= mScaleFactor
            if (saveScale > MAX_SCALE) {
                saveScale = MAX_SCALE
                mScaleFactor = MAX_SCALE / origScale
            } else if (saveScale < MIN_SCALE) {
                saveScale = MIN_SCALE
                mScaleFactor = MIN_SCALE / origScale
            }
            if (origWidth * saveScale <= viewWidth || origHeight * saveScale <= viewHeight) {
                imageMatrix.postScale(
                    mScaleFactor, mScaleFactor, (viewWidth / 2).toFloat(),
                    (viewHeight / 2).toFloat()
                )
            } else {
                imageMatrix.postScale(
                    mScaleFactor, mScaleFactor,
                    detector.focusX, detector.focusY
                )
            }
            fixTranslation()
            return true
        }
    }

    private inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            onTap?.invoke()
            return true
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            // 双击切换 1x <-> 2.5x
            val targetScale = if (saveScale > 1.2f) 1f else DBL_TAP_SCALE
            val origScale = saveScale
            val deltaScale = targetScale / origScale
            saveScale = targetScale
            if (origWidth * saveScale <= viewWidth || origHeight * saveScale <= viewHeight) {
                imageMatrix.postScale(
                    deltaScale, deltaScale, (viewWidth / 2).toFloat(),
                    (viewHeight / 2).toFloat()
                )
            } else {
                imageMatrix.postScale(deltaScale, deltaScale, e.x, e.y)
            }
            fixTranslation()
            return true
        }
    }

    private fun onTouch(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        gestureDetector.onTouchEvent(event)

        val curr = PointF(event.x, event.y)
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                start.set(curr)
                mode = DRAG
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                oldDist = spacing(event)
                if (oldDist > 10f) {
                    midPoint(mid, event)
                    mode = ZOOM
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == DRAG && saveScale > 1.0f) {
                    val dx = curr.x - start.x
                    val dy = curr.y - start.y
                    imageMatrix.postTranslate(dx, dy)
                    fixTranslation()
                    start.set(curr)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                mode = NONE
            }
        }
        imageMatrix = imageMatrix
        return true
    }

    private fun fixTranslation() {
        imageMatrix.getValues(matrixValues)
        val transX = matrixValues[Matrix.MTRANS_X]
        val transY = matrixValues[Matrix.MTRANS_Y]
        val fixTransX = getFixTrans(transX, viewWidth.toFloat(), origWidth * saveScale)
        val fixTransY = getFixTrans(
            transY, viewHeight.toFloat(), origHeight
                    * saveScale
        )
        if (fixTransX != 0f || fixTransY != 0f) {
            imageMatrix.postTranslate(fixTransX, fixTransY)
        }
    }

    private fun getFixTrans(trans: Float, viewSize: Float, contentSize: Float): Float {
        val minTrans: Float
        val maxTrans: Float
        if (contentSize <= viewSize) {
            minTrans = 0f
            maxTrans = viewSize - contentSize
        } else {
            minTrans = viewSize - contentSize
            maxTrans = 0f
        }
        if (trans < minTrans) return -trans + minTrans
        if (trans > maxTrans) return -trans + maxTrans
        return 0f
    }

    private fun spacing(event: MotionEvent): Float {
        val x = event.getX(0) - event.getX(1)
        val y = event.getY(0) - event.getY(1)
        return kotlin.math.sqrt((x * x + y * y).toDouble()).toFloat()
    }

    private fun midPoint(point: PointF, event: MotionEvent) {
        val x = event.getX(0) + event.getX(1)
        val y = event.getY(0) + event.getY(1)
        point[x / 2] = y / 2
    }

    override fun setFrame(l: Int, t: Int, r: Int, b: Int): Boolean {
        val changed = super.setFrame(l, t, r, b)
        viewWidth = r - l
        viewHeight = b - t
        val d = drawable
        if (d != null && d.intrinsicWidth != 0 && d.intrinsicHeight != 0) {
            val bmWidth = d.intrinsicWidth
            val bmHeight = d.intrinsicHeight
            val scaleX = viewWidth.toFloat() / bmWidth.toFloat()
            val scaleY = viewHeight.toFloat() / bmHeight.toFloat()
            val scale = min(scaleX, scaleY)
            baseMatrix.setScale(scale, scale)
            origWidth = viewWidth / scale
            origHeight = viewHeight / scale
            // 居中
            val redundantXSpace = viewWidth - scale * bmWidth
            val redundantYSpace = viewHeight - scale * bmHeight
            baseMatrix.postTranslate(redundantXSpace / 2, redundantYSpace / 2)
            if (saveScale == 1f) {
                imageMatrix = baseMatrix
            } else {
                // 保持已设置的 zoom，但在 view 变了时重新应用
                val zoom = saveScale
                imageMatrix = Matrix(baseMatrix).apply { postScale(zoom, zoom) }
            }
        }
        return changed
    }

    fun resetZoom() {
        saveScale = 1f
        imageMatrix = baseMatrix
    }

    companion object {
        private const val NONE = 0
        private const val DRAG = 1
        private const val ZOOM = 2
        private const val MAX_SCALE = 5.0f
        private const val MIN_SCALE = 0.8f
        private const val DBL_TAP_SCALE = 2.5f
    }
}
