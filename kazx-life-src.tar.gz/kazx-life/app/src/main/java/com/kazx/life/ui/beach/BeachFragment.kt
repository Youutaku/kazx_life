package com.kazx.life.ui.beach

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.kazx.life.R
import com.kazx.life.data.BeachShop
import com.kazx.life.databinding.FragmentBeachBinding
import com.kazx.life.net.AccentHelper
import com.kazx.life.repo.BbqRepository
import kotlinx.coroutines.launch

/** 必吃榜首页：店铺网格列表 + Hero。 */
class BeachFragment : Fragment() {

    private lateinit var binding: FragmentBeachBinding
    private lateinit var adapter: BeachShopAdapter
    private val repo = BbqRepository()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentBeachBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = BeachShopAdapter(::goDetail)
        val lm = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        binding.recycler.layoutManager = lm
        binding.recycler.adapter = adapter
        binding.recycler.isNestedScrollingEnabled = false

        // hero 渐变动态应用主题色
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        val hero = binding.root.getChildAt(0) as? ViewGroup
        (hero?.getChildAt(0) as? ViewGroup)?.let {
            // Hero 是第一个 LinearLayout，找到它通过 tag 或直接用 id，这里直接覆盖 LinearLayout
        }
        // 使用 findViewById 找到 Hero 的 LinearLayout（带标题）
        val heroView = binding.root.findViewById<ViewGroup>(R.id.loadingView)
            .parent.parent as ViewGroup
        // 找到 Hero（第一个 LinearLayout）
        (binding.root.getChildAt(0) as? androidx.core.widget.NestedScrollView)?.getChildAt(0)
            ?.let { root -> (root as ViewGroup).getChildAt(0) as? View }?.let { v ->
                v.background = gd
            }

        binding.swipeRefresh.setOnRefreshListener { load(true) }
        binding.btnRetry.setOnClickListener { load(false) }

        load(false)
    }

    override fun onResume() {
        super.onResume()
        // 重新应用主题色到 hero
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        (binding.root.getChildAt(0) as? androidx.core.widget.NestedScrollView)?.getChildAt(0)
            ?.let { root -> (root as ViewGroup).getChildAt(0) as? View }?.let { v ->
                v.background = gd
            }
    }

    private fun load(forceRefresh: Boolean) {
        binding.emptyView.visibility = View.GONE
        binding.recycler.visibility = View.GONE
        if (!forceRefresh) binding.loadingView.visibility = View.VISIBLE
        binding.swipeRefresh.isRefreshing = forceRefresh

        viewLifecycleOwner.lifecycleScope.launch {
            when (val r = repo.getBeachShopList()) {
                is com.kazx.life.data.ApiResult.Success<List<BeachShop>> -> {
                    binding.loadingView.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    val list = r.data
                    if (list.isEmpty()) {
                        binding.emptyText.setText(R.string.empty)
                        binding.btnRetry.visibility = View.GONE
                        binding.emptyView.visibility = View.VISIBLE
                    } else {
                        adapter.set(list)
                        binding.recycler.visibility = View.VISIBLE
                    }
                }
                is com.kazx.life.data.ApiResult.Error -> {
                    binding.loadingView.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    binding.emptyText.text = r.message
                    binding.btnRetry.visibility = View.VISIBLE
                    binding.emptyView.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun goDetail(shop: BeachShop) {
        startActivity(Intent(requireContext(), BeachDetailActivity::class.java).apply {
            putExtra("shop_id", shop.id)
            putExtra("shop_name", shop.name)
        })
    }
}
