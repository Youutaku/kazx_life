package com.kazx.life.ui.home

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.data.Post
import com.kazx.life.databinding.FragmentHomeBinding
import com.kazx.life.databinding.ItemPostBinding
import com.kazx.life.repo.BbqRepository
import com.kazx.life.ui.PhotoViewerActivity
import com.kazx.life.ui.detail.DetailActivity
import kotlinx.coroutines.launch

/**
 * 表白墙首页：下拉刷新 + 上拉分页 + 点赞。
 */
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val repo = BbqRepository()

    private val adapter = PostAdapter(
        onClick = { openDetail(it.id) },
        onLike = { post, cb -> like(post, cb) },
        onComment = { openDetail(it.id) },
        onReport = { openDetail(it.id) }
    )

    private val posts = mutableListOf<Post>()
    private var loadedCount = 0
    private var hasMore = true
    private var isLoading = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
        binding.swipe.setOnRefreshListener { refresh() }
        binding.stateRetry.setOnClickListener { refresh() }
        binding.recycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                val lm = rv.layoutManager as LinearLayoutManager
                if (hasMore && !isLoading && lm.findLastVisibleItemPosition() >= posts.size - 3) {
                    loadMore()
                }
            }
        })
        refresh()
    }

    private fun refresh() {
        binding.swipe.isRefreshing = true
        viewLifecycleOwner.lifecycleScope.launch {
            when (val r = repo.getInitialPosts()) {
                is ApiResult.Success -> {
                    posts.clear()
                    posts.addAll(r.data)
                    loadedCount = r.data.size.coerceAtLeast(10)
                    hasMore = true
                    adapter.submit(posts)
                    showState(false, "")
                }
                is ApiResult.Error -> {
                    if (posts.isEmpty()) showState(true, r.message)
                    else snack(r.message)
                }
            }
            binding.swipe.isRefreshing = false
        }
    }

    private fun loadMore() {
        if (isLoading) return
        isLoading = true
        adapter.showFooterLoading(true)
        viewLifecycleOwner.lifecycleScope.launch {
            when (val r = repo.loadMore(loadedCount)) {
                is ApiResult.Success -> {
                    posts.addAll(r.data.posts)
                    loadedCount += r.data.loaded.coerceAtLeast(r.data.posts.size)
                    hasMore = r.data.hasMore
                    adapter.submit(posts)
                    if (!hasMore) adapter.showFooterNoMore(true)
                }
                is ApiResult.Error -> snack(r.message)
            }
            adapter.showFooterLoading(false)
            isLoading = false
        }
    }

    private fun like(post: Post, cb: (Int, Boolean) -> Unit) {
        viewLifecycleOwner.lifecycleScope.launch {
            when (val r = repo.like(post.id)) {
                is ApiResult.Success -> cb(r.data, true)
                is ApiResult.Error -> snack(r.message)
            }
        }
    }

    private fun openDetail(id: String) {
        startActivity(Intent(requireContext(), DetailActivity::class.java).putExtra("id", id))
    }

    private fun snack(msg: String) {
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
    }

    private fun showState(show: Boolean, msg: String) {
        binding.stateView.visibility = if (show) View.VISIBLE else View.GONE
        binding.stateText.text = msg
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

/**
 * 帖子列表适配器。支持普通卡片 + 尾部加载/无更多。
 */
class PostAdapter(
    private val onClick: (Post) -> Unit,
    private val onLike: (Post, (Int, Boolean) -> Unit) -> Unit,
    private val onComment: (Post) -> Unit,
    private val onReport: (Post) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val items = mutableListOf<Post>()
    private var footerLoading = false
    private var footerNoMore = false

    companion object {
        private const val TYPE_POST = 0
        private const val TYPE_FOOTER = 1
    }

    fun submit(list: List<Post>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun showFooterLoading(show: Boolean) {
        if (footerLoading == show) return
        footerLoading = show
        if (show) {
            footerNoMore = false
            notifyItemChanged(itemCount - 1)
        }
    }

    fun showFooterNoMore(show: Boolean) {
        if (footerNoMore == show) return
        footerNoMore = show
        notifyItemChanged(itemCount - 1)
    }

    override fun getItemCount(): Int = items.size + 1

    override fun getItemViewType(position: Int): Int =
        if (position == items.size) TYPE_FOOTER else TYPE_POST

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_FOOTER -> FooterHolder(inflater.inflate(R.layout.item_footer, parent, false))
            else -> PostHolder(ItemPostBinding.inflate(inflater, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        if (holder is PostHolder) holder.bind(items[position])
        else (holder as FooterHolder).bind(footerLoading, footerNoMore)
    }

    inner class PostHolder(private val vb: ItemPostBinding) : RecyclerView.ViewHolder(vb.root) {
        fun bind(post: Post) {
            // 头像：圆形彩色背景 + 首字
            val gd = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor(safeColor(post.avatarColor)))
            }
            vb.avatar.background = gd
            vb.avatar.text = post.avatarText
            vb.nickname.text = post.nickname
            vb.badgeAdmin.visibility = if (post.isAdmin) View.VISIBLE else View.GONE
            vb.badgePinned.visibility = if (post.isPinned) View.VISIBLE else View.GONE
            vb.time.text = post.time
            vb.content.text = post.content
            vb.topic.visibility = if (!post.topic.isNullOrBlank()) View.VISIBLE else View.GONE
            vb.topic.text = post.topic ?: ""

            // 图片：1 张大图，多张网格，0 张隐藏；点击都打开大图查看器
            vb.imageSingle.visibility = View.GONE
            vb.imageGrid.visibility = View.GONE
            val openPhoto: (Int) -> Unit = { idx ->
                val ctx = vb.root.context
                ctx.startActivity(
                    android.content.Intent(ctx, PhotoViewerActivity::class.java)
                        .putStringArrayListExtra(
                            PhotoViewerActivity.EXTRA_IMAGES,
                            ArrayList(post.images)
                        )
                        .putExtra(PhotoViewerActivity.EXTRA_INDEX, idx)
                )
            }
            when {
                post.images.size == 1 -> {
                    vb.imageSingle.visibility = View.VISIBLE
                    Glide.with(vb.root).load(post.images[0]).into(vb.imageSingle)
                    vb.imageSingle.setOnClickListener { openPhoto(0) }
                }
                post.images.size > 1 -> {
                    vb.imageGrid.visibility = View.VISIBLE
                    vb.imageGrid.layoutManager = androidx.recyclerview.widget.GridLayoutManager(
                        vb.root.context, 3
                    )
                    vb.imageGrid.adapter = ImageGridAdapter(post.images) { _, idx ->
                        openPhoto(idx)
                    }
                }
            }

            vb.likeCount.text = post.likeCount.toString()
            vb.commentCount.text = post.commentCount.toString()
            vb.iconLike.setColorFilter(
                if (post.liked) Color.parseColor("#EC407A") else Color.parseColor("#A39AA6")
            )

            vb.root.setOnClickListener { onClick(post) }
            vb.btnLike.setOnClickListener {
                onLike(post) { count, liked ->
                    val p = items[bindingAdapterPosition]
                    items[bindingAdapterPosition] = p.copy(likeCount = count, liked = liked)
                    notifyItemChanged(bindingAdapterPosition)
                }
            }
            vb.btnComment.setOnClickListener { onComment(post) }
            vb.btnReport.setOnClickListener { onReport(post) }
        }

        private fun safeColor(c: String): String =
            if (c.matches(Regex("#[0-9A-Fa-f]{3,8}"))) c else "#9C27B0"
    }

    inner class FooterHolder(v: View) : RecyclerView.ViewHolder(v) {
        fun bind(loading: Boolean, noMore: Boolean) {
            itemView.findViewById<View>(R.id.footer_progress).visibility =
                if (loading) View.VISIBLE else View.GONE
            itemView.findViewById<android.widget.TextView>(R.id.footer_text).text =
                when {
                    loading -> itemView.context.getString(R.string.loading_more)
                    noMore -> itemView.context.getString(R.string.no_more)
                    else -> ""
                }
        }
    }
}
