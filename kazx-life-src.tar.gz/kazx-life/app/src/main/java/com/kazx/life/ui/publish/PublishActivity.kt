package com.kazx.life.ui.publish

import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.net.AccentHelper
import com.kazx.life.databinding.ActivityPublishBinding
import com.kazx.life.databinding.DialogCaptchaBinding
import com.kazx.life.databinding.ItemPublishImageBinding
import com.kazx.life.repo.BbqRepository
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * 发帖：昵称 + 内容 + 图片(上传) + 话题，发布时校验验证码后提交 post.php。
 * 流程与网站 post.php 一致：captcha → verify_captcha → 表单提交。
 */
class PublishActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPublishBinding
    private val repo = BbqRepository()

    /** mediaList：每项 = 站点返回的 {file, type}。 */
    private val mediaList = mutableListOf<JSONObject>()
    /** 本地图片项（uri + 上传状态），与 mediaList 顺序对应。 */
    private val localItems = mutableListOf<LocalImage>()
    private val imageAdapter = PublishImageAdapter()

    private val pickImages = registerForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(8)
    ) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        for (u in uris) addImage(u)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPublishBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.imageList.layoutManager = GridLayoutManager(this, 4)
        binding.imageList.adapter = imageAdapter
        imageAdapter.onAdd = { pickImages.launch(androidx.activity.result.PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        imageAdapter.onRemove = { removeAt(it) }

        binding.btnSubmit.setOnClickListener { onSubmit() }
    }

    override fun onResume() {
        super.onResume()
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
    }

    private fun addImage(uri: Uri) {
        val idx = localItems.size
        localItems.add(LocalImage(uri = uri, uploading = true))
        imageAdapter.submit(localItems)
        // 复制到本地文件并上传
        lifecycleScope.launch {
            val file = uriToFile(uri) ?: run {
                markUploadFailed(idx); return@launch
            }
            val mime = contentResolver.getType(uri) ?: "image/jpeg"
            when (val r = repo.upload(file, mime)) {
                is ApiResult.Success -> {
                    val obj = JSONObject().apply {
                        put("file", r.data.optString("file", r.data.optString("path", "")))
                        put("type", r.data.optString("type", "image"))
                    }
                    if (idx < mediaList.size) mediaList[idx] = obj else mediaList.add(obj)
                    if (idx < localItems.size) {
                        localItems[idx] = localItems[idx].copy(uploading = false, error = false)
                        imageAdapter.submit(localItems)
                    }
                }
                is ApiResult.Error -> {
                    if (idx < mediaList.size) mediaList.removeAt(idx)
                    markUploadFailed(idx)
                    Snackbar.make(binding.root, "图片上传失败：${r.message}", Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun markUploadFailed(idx: Int) {
        if (idx < localItems.size) {
            localItems[idx] = localItems[idx].copy(uploading = false, error = true)
            imageAdapter.submit(localItems)
        }
    }

    private fun removeAt(idx: Int) {
        if (idx >= localItems.size) return
        localItems.removeAt(idx)
        if (idx < mediaList.size) mediaList.removeAt(idx)
        imageAdapter.submit(localItems)
    }

    private fun onSubmit() {
        val content = binding.content.text?.toString()?.trim().orEmpty()
        if (content.isEmpty()) {
            Snackbar.make(binding.root, getString(R.string.content_empty), Snackbar.LENGTH_SHORT).show()
            return
        }
        if (localItems.any { it.uploading }) {
            Snackbar.make(binding.root, getString(R.string.uploading), Snackbar.LENGTH_SHORT).show()
            return
        }
        // 1. 拉验证码
        binding.btnSubmit.isEnabled = false
        lifecycleScope.launch {
            when (val r = repo.getCaptcha()) {
                is ApiResult.Success -> showCaptchaDialog(r.data, content)
                is ApiResult.Error -> {
                    binding.btnSubmit.isEnabled = true
                    Snackbar.make(binding.root, r.message, Snackbar.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showCaptchaDialog(base64: String, content: String) {
        val vb = DialogCaptchaBinding.inflate(layoutInflater)
        val data = base64.substringAfter("base64,", base64)
        runCatching {
            val bytes = Base64.decode(data, Base64.DEFAULT)
            vb.captchaImg.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.size))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle("请输入验证码")
            .setView(vb.root)
            .setPositiveButton(R.string.ok) { _, _ ->
                val code = vb.captchaCode.text?.toString()?.trim().orEmpty()
                if (code.isEmpty()) {
                    Snackbar.make(binding.root, getString(R.string.captcha_error), Snackbar.LENGTH_SHORT).show()
                    binding.btnSubmit.isEnabled = true
                    return@setPositiveButton
                }
                verifyAndPublish(code, content)
            }
            .setNegativeButton(R.string.cancel) { _, _ -> binding.btnSubmit.isEnabled = true }
            .setOnCancelListener { binding.btnSubmit.isEnabled = true }
            .create()
        dialog.show()
    }

    private fun verifyAndPublish(code: String, content: String) {
        lifecycleScope.launch {
            when (val vr = repo.verifyCaptcha(code)) {
                is ApiResult.Success -> {
                    if (!vr.data) {
                        Snackbar.make(binding.root, getString(R.string.captcha_error), Snackbar.LENGTH_SHORT).show()
                        binding.btnSubmit.isEnabled = true
                        return@launch
                    }
                    doPublish(content)
                }
                is ApiResult.Error -> {
                    Snackbar.make(binding.root, vr.message, Snackbar.LENGTH_SHORT).show()
                    binding.btnSubmit.isEnabled = true
                }
            }
        }
    }

    private fun doPublish(content: String) {
        val nickname = binding.nickname.text?.toString()?.trim().orEmpty()
        val topic = binding.topic.text?.toString()?.trim().orEmpty()
        val mediaArr = JSONArray()
        mediaList.forEach { mediaArr.put(it) }
        lifecycleScope.launch {
            when (val r = repo.publish(nickname, content, mediaArr.toString(), topic, fingerprint())) {
                is ApiResult.Success -> {
                    Snackbar.make(binding.root, getString(R.string.publish_success), Snackbar.LENGTH_SHORT).show()
                    binding.root.postDelayed({ finish() }, 700)
                }
                is ApiResult.Error -> {
                    Snackbar.make(binding.root, "${getString(R.string.publish_failed)}：${r.message}", Snackbar.LENGTH_SHORT).show()
                }
            }
            binding.btnSubmit.isEnabled = true
        }
    }

    /** 把 content Uri 复制到 cacheDir 以便上传。 */
    private fun uriToFile(uri: Uri): File? = runCatching {
        val dest = File(cacheDir, "upload_${System.currentTimeMillis()}_${UUID.randomUUID()}.jpg")
        contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { input.copyTo(it) }
        } ?: return null
        dest
    }.getOrNull()

    private fun fingerprint(): String {
        val prefs = getSharedPreferences("kazx_prefs", MODE_PRIVATE)
        var fp = prefs.getString("fingerprint", null)
        if (fp.isNullOrEmpty()) {
            fp = UUID.randomUUID().toString().replace("-", "")
            prefs.edit().putString("fingerprint", fp).apply()
        }
        return fp
    }

    // —— 图片项模型与适配器 ——
    data class LocalImage(val uri: Uri, val uploading: Boolean, val error: Boolean = false)

    class PublishImageAdapter : RecyclerView.Adapter<PublishImageAdapter.VH>() {
        private val items = mutableListOf<LocalImage>()
        var onAdd: () -> Unit = {}
        var onRemove: (Int) -> Unit = {}

        fun submit(list: List<LocalImage>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size + 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val b = ItemPublishImageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return VH(b)
        }

        override fun onBindViewHolder(h: VH, position: Int) {
            if (position == items.size) {
                // 末尾的"+"添加项
                h.binding.img.setImageDrawable(null)
                h.binding.img.setBackgroundColor(0xFFEDE4F1.toInt())
                h.binding.img.setImageResource(android.R.drawable.ic_input_add)
                h.binding.remove.visibility = View.GONE
                h.binding.progress.visibility = View.GONE
                h.binding.img.setOnClickListener { onAdd() }
            } else {
                val item = items[position]
                Glide.with(h.binding.img).load(item.uri).centerCrop().into(h.binding.img)
                h.binding.remove.visibility = View.VISIBLE
                h.binding.progress.visibility = if (item.uploading) View.VISIBLE else View.GONE
                h.binding.remove.setOnClickListener { onRemove(position) }
                h.binding.img.setOnClickListener(null)
            }
        }

        class VH(val binding: ItemPublishImageBinding) : RecyclerView.ViewHolder(binding.root)
    }
}
