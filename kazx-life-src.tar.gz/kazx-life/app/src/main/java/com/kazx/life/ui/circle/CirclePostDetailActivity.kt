package com.kazx.life.ui.circle

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.data.CircleComment
import com.kazx.life.data.CirclePostDetail
import com.kazx.life.databinding.ActivityCirclePostDetailBinding
import com.kazx.life.databinding.ItemCircleCommentBinding
import com.kazx.life.repo.BbqRepository
import com.kazx.life.ui.PhotoViewerActivity
import com.kazx.life.ui.home.ImageGridAdapter
import kotlinx.coroutines.launch

class CirclePostDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "post_id"
        const val EXTRA_CIRCLE_ID = "circle_id"
    }

    private lateinit var binding: ActivityCirclePostDetailBinding
    private val repo = BbqRepository()
    private lateinit var postId: String
    private var circleId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCirclePostDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        postId = intent.getStringExtra(EXTRA_ID) ?: ""
        circleId = intent.getStringExtra(EXTRA_CIRCLE_ID) ?: ""
        load()
    }

    private fun load() {
        lifecycleScope.launch {
            when (val r = repo.getCirclePostDetail(postId, circleId)) {
                is ApiResult.Success -> bind(r.data)
                is ApiResult.Error -> snack(r.message)
            }
        }
    }

    private fun bind(d: CirclePostDetail) {
        val p = d.post
        // 头像
        val gd = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(colorForName(p.author.ifEmpty { p.avatarText }))
        }
        binding.avatar.background = gd
        binding.avatar.text = p.avatarText
        binding.author.text = p.author.ifEmpty { "匿名用户" }
        binding.time.text = p.time

        // 所属圈子
        if (d.circleName.isNotEmpty()) {
            binding.circleName.text = d.circleName
            binding.circleName.visibility = View.VISIBLE
        }

        binding.title.text = p.title
        binding.content.text = d.content.ifEmpty { p.summary }

        // 图片
        if (d.images.isNotEmpty()) {
            binding.imageGrid.visibility = View.VISIBLE
            binding.imageGrid.layoutManager = GridLayoutManager(this, 3)
            binding.imageGrid.adapter = ImageGridAdapter(d.images) { _, idx ->
                startActivity(
                    Intent(this, PhotoViewerActivity::class.java)
                        .putStringArrayListExtra(
                            PhotoViewerActivity.EXTRA_IMAGES,
                            ArrayList(d.images)
                        )
                        .putExtra(PhotoViewerActivity.EXTRA_INDEX, idx)
                )
            }
            // 单张大图
            if (d.images.size == 1) {
                binding.imageGrid.layoutManager = GridLayoutManager(this, 1)
            }
        }

        // 评论
        bindComments(d.comments)
    }

    private fun bindComments(list: List<CircleComment>) {
        binding.commentsTitle.text = getString(R.string.circle_comments_fmt, list.size)
        binding.emptyComments.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        binding.commentsContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        list.forEach { c ->
            val vb = ItemCircleCommentBinding.inflate(inflater, binding.commentsContainer, false)
            val gd = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(colorForName(c.nickname))
            }
            vb.avatar.background = gd
            vb.avatar.text = c.avatarText
            vb.nickname.text = c.nickname
            vb.time.text = c.time
            vb.content.text = c.content
            binding.commentsContainer.addView(vb.root)
        }
    }

    private fun snack(msg: String) {
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
    }

    private fun colorForName(name: String): Int {
        val colors = arrayOf(
            "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
            "#009688", "#4CAF50", "#FF9800", "#F44336", "#E91E63"
        )
        val idx = (name.hashCode() and 0x7fffffff) % colors.size
        return Color.parseColor(colors[idx])
    }
}
