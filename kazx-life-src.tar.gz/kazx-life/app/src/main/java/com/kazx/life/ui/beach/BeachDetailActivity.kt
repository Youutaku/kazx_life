package com.kazx.life.ui.beach

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.data.BeachReview
import com.kazx.life.data.BeachShopDetail
import com.kazx.life.databinding.ActivityBeachDetailBinding
import com.kazx.life.databinding.ItemBeachReviewBinding
import com.kazx.life.net.AccentHelper
import com.kazx.life.repo.BbqRepository
import com.kazx.life.ui.PhotoViewerActivity
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/** 必吃榜店铺详情页。 */
class BeachDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBeachDetailBinding
    private lateinit var shopId: String
    private val repo = BbqRepository()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shopId = intent.getStringExtra("shop_id").orEmpty()
        val name = intent.getStringExtra("shop_name").orEmpty()
        binding = ActivityBeachDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.title = getString(R.string.beach_detail)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // 主题色渐变
        applyAccent()

        if (name.isNotEmpty()) binding.name.text = name
        load()
    }

    override fun onResume() {
        super.onResume()
        applyAccent()
    }

    private fun applyAccent() {
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
    }

    private fun load() {
        lifecycleScope.launch {
            when (val r = repo.getBeachShopDetail(shopId)) {
                is ApiResult.Success<BeachShopDetail> -> bindDetail(r.data)
                is ApiResult.Error -> {
                    binding.name.text = "加载失败：${r.message}"
                }
            }
        }
    }

    private fun bindDetail(d: com.kazx.life.data.BeachShopDetail) {
        binding.toolbar.title = d.name.ifEmpty { getString(R.string.beach_detail) }
        binding.name.text = d.name
        binding.badgeClaimed.visibility = if (d.claimed) View.VISIBLE else View.GONE

        // 评分
        val rating = d.rating.coerceIn(0f, 5f)
        if (d.rating < 0) {
            binding.stars.text = "☆☆☆☆☆"
            binding.ratingText.text = getString(R.string.beach_rating_pending)
        } else {
            val filled = rating.roundToInt().coerceIn(0, 5)
            binding.stars.text = "★".repeat(filled) + "☆".repeat(5 - filled)
            binding.ratingText.text = getString(R.string.beach_rating_fmt, rating, d.rateCount)
        }
        binding.address.text = d.address.ifEmpty { getString(R.string.beach_address_hint) }

        // 封面
        if (d.cover.isNotEmpty()) {
            binding.coverText.visibility = View.GONE
            binding.cover.visibility = View.VISIBLE
            Glide.with(this).load(d.cover).placeholder(R.drawable.bg_chip).centerCrop().into(binding.cover)
        } else {
            binding.cover.visibility = View.GONE
            binding.coverText.visibility = View.VISIBLE
            binding.coverText.text = d.coverText.ifEmpty { d.name.firstOrNull()?.toString() ?: " " }
        }

        // 电话
        if (d.phone.isNotEmpty()) {
            binding.phone.text = "电话：${d.phone}"
            binding.phoneRow.visibility = View.VISIBLE
            binding.phoneRow.setOnClickListener {
                runCatching {
                    startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${d.phone}"))) }
            }
        } else {
            binding.phoneRow.visibility = View.GONE
        }

        // QQ
        if (d.qq.isNotEmpty()) {
            binding.qq.text = "QQ：${d.qq}"
            binding.qqRow.visibility = View.VISIBLE
            binding.qqRow.setOnClickListener {
                runCatching {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse("mqqwpa://im/chat?chat_type=wpa&uin=${d.qq}&version=1"))
                        if (packageManager.resolveActivity(i, 0) != null) startActivity(i)
                }
            }
        } else {
            binding.qqRow.visibility = View.GONE
        }

        // 菜单
        bindMenu(d.menuImages)
        // 评价
        bindReviews(d.reviews)
    }

    private fun bindMenu(menus: List<String>) {
        if (menus.isEmpty()) {
            binding.menuCard.visibility = View.GONE
            return
        }
        binding.menuCard.visibility = View.VISIBLE
        val ll = binding.menuContainer
        ll.removeAllViews()
        val density = resources.displayMetrics.density
        val pad = (8 * density).toInt()
        menus.forEachIndexed { idx, url ->
            val iv = ImageView(this)
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                if (idx > 0) topMargin = pad
            }
            iv.layoutParams = lp
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.adjustViewBounds = true
            iv.contentDescription = null
            Glide.with(this).load(url).placeholder(R.drawable.bg_chip).into(iv)
            iv.setOnClickListener { openPhoto(menus, idx) }
            ll.addView(iv)
        }
    }

    private fun bindReviews(reviews: List<BeachReview>) {
        binding.reviewTitle.text = getString(R.string.beach_review_fmt, reviews.size)
        val ll = binding.reviewContainer
        ll.removeAllViews()
        if (reviews.isEmpty()) {
            binding.reviewEmpty.visibility = View.VISIBLE
            return
        }
        binding.reviewEmpty.visibility = View.GONE
        reviews.forEach { r ->
            val vb = ItemBeachReviewBinding.inflate(layoutInflater, ll, false)
            vb.nickname.text = r.nickname
            vb.avatar.text = r.avatarText
            vb.time.text = r.time
            val rating = r.rating.coerceIn(0f, 5f)
            val filled = rating.roundToInt().coerceIn(0, 5)
            vb.stars.text = "★".repeat(filled) + "☆".repeat(5 - filled)
            vb.content.text = r.content
            ll.addView(vb.root)
        }
    }

    private fun openPhoto(urls: List<String>, index: Int) {
        if (urls.isEmpty()) return
        val i = Intent(this, PhotoViewerActivity::class.java).apply {
            putStringArrayListExtra("urls", ArrayList(urls))
            putExtra("index", index)
        }
        startActivity(i)
    }
}
