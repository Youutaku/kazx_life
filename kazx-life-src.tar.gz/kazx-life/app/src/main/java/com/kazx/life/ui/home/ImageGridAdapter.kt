package com.kazx.life.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kazx.life.databinding.ItemImageBinding

/**
 * 帖子内多图网格适配器。
 * @param onImageClick 点击图片回调：参数 (全部图片列表, 点击的下标)
 */
class ImageGridAdapter(
    private val images: List<String>,
    private val onImageClick: ((List<String>, Int) -> Unit)? = null
) : RecyclerView.Adapter<ImageGridAdapter.VH>() {

    class VH(val binding: ItemImageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemImageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        Glide.with(holder.binding.img.context)
            .load(images[position])
            .centerCrop()
            .into(holder.binding.img)
        holder.binding.img.setOnClickListener {
            onImageClick?.invoke(images, position)
        }
    }

    override fun getItemCount(): Int = images.size
}
