package com.kazx.life.repo

import com.kazx.life.data.ApiResult
import com.kazx.life.data.BeachParser
import com.kazx.life.data.BeachShop
import com.kazx.life.data.BeachShopDetail
import com.kazx.life.data.Circle
import com.kazx.life.data.CircleDetail
import com.kazx.life.data.CircleParser
import com.kazx.life.data.CirclePostDetail
import com.kazx.life.data.ListPage
import com.kazx.life.data.Post
import com.kazx.life.data.PostDetail
import com.kazx.life.data.PostParser
import com.kazx.life.net.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File

/**
 * 表白墙数据仓库：把对 api.php / 页面的请求封装为 suspend 函数，返回 ApiResult。
 */
class BbqRepository {

    /** 首页初始帖子（解析 index.php，约 10 条）。 */
    suspend fun getInitialPosts(): ApiResult<List<Post>> = withContext(Dispatchers.IO) {
        runCatching {
            Net.get("index.php").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                ApiResult.Success(PostParser.parseIndexPage(html))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 分页加载更多。offset 从 10 起。 */
    suspend fun loadMore(offset: Int, limit: Int = 10): ApiResult<ListPage> = withContext(Dispatchers.IO) {
        runCatching {
            Net.get("api.php?action=load_more_posts&offset=$offset&limit=$limit").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val raw = resp.body?.string() ?: ""
                val json = JSONObject(raw)
                if (!json.optBoolean("success", false)) {
                    return@use ApiResult.Success(ListPage(emptyList(), 0, false))
                }
                val html = json.optString("html", "")
                val posts = PostParser.parseListHtml(html)
                val loaded = json.optInt("loaded", posts.size)
                val hasMore = json.optBoolean("has_more", posts.isNotEmpty())
                ApiResult.Success(ListPage(posts, loaded, hasMore))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 帖子详情。 */
    suspend fun getDetail(id: String): ApiResult<PostDetail> = withContext(Dispatchers.IO) {
        runCatching {
            Net.get("detail.php?id=$id").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                val detail = PostParser.parseDetailPage(html)
                    ?: return@use ApiResult.Error("解析失败")
                ApiResult.Success(detail)
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 点赞，返回最新点赞数。 */
    suspend fun like(postId: String): ApiResult<Int> = withContext(Dispatchers.IO) {
        runCatching {
            Net.postForm("api.php?action=like", mapOf("post_id" to postId)).use { resp ->
                val json = JSONObject(resp.body?.string() ?: "{}")
                if (json.optBoolean("success", false))
                    ApiResult.Success(json.optInt("likes", 0))
                else ApiResult.Error(json.optString("error", "操作失败"))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 举报。 */
    suspend fun report(
        postId: String, reason: String, detail: String, fingerprint: String = ""
    ): ApiResult<String> = withContext(Dispatchers.IO) {
        runCatching {
            Net.postForm("api.php?action=report_post", mapOf(
                "post_id" to postId,
                "reason" to reason,
                "detail" to detail,
                "fingerprint" to fingerprint
            )).use { resp ->
                val json = JSONObject(resp.body?.string() ?: "{}")
                if (json.optBoolean("success", false))
                    ApiResult.Success(json.optString("message", "举报成功"))
                else ApiResult.Error(json.optString("error", "举报失败"))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 发表评论。 */
    suspend fun comment(
        postId: String, nickname: String, content: String, fingerprint: String = ""
    ): ApiResult<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            Net.postForm("api.php?action=comment", mapOf(
                "post_id" to postId,
                "nickname" to nickname.ifEmpty { "匿名用户" },
                "content" to content,
                "fingerprint" to fingerprint
            )).use { resp ->
                val json = JSONObject(resp.body?.string() ?: "{}")
                if (json.optBoolean("success", false)) ApiResult.Success(Unit)
                else ApiResult.Error(json.optString("error", "评论失败"))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 获取验证码图（base64 data uri）。 */
    suspend fun getCaptcha(): ApiResult<String> = withContext(Dispatchers.IO) {
        runCatching {
            Net.get("api.php?action=captcha").use { resp ->
                val json = JSONObject(resp.body?.string() ?: "{}")
                if (json.optBoolean("success", false))
                    ApiResult.Success(json.optString("image", ""))
                else ApiResult.Error("获取验证码失败")
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 校验验证码。 */
    suspend fun verifyCaptcha(code: String): ApiResult<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            Net.postForm("api.php?action=verify_captcha", mapOf("code" to code)).use { resp ->
                val json = JSONObject(resp.body?.string() ?: "{}")
                ApiResult.Success(json.optBoolean("success", false))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 上传单个文件，返回站点返回的文件信息 JSON 字符串（含 file/type）。 */
    suspend fun upload(file: File, mime: String): ApiResult<JSONObject> = withContext(Dispatchers.IO) {
        runCatching {
            val part = MultipartBody.Part.createFormData(
                "file", file.name, file.asRequestBody(mime.toMediaTypeOrNull())
            )
            Net.postMultipart("api.php?action=upload", "file", part).use { resp ->
                val json = JSONObject(resp.body?.string() ?: "{}")
                if (json.optBoolean("success", false)) ApiResult.Success(json)
                else ApiResult.Error(json.optString("error", "上传失败"))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /**
     * 发布帖子。post.php 接收表单字段：nickname, content, media(JSON), fingerprint, topic。
     * 返回时通过 HTTP 跳转/响应判断成功（站点提交后一般 302 跳回首页）。
     */
    suspend fun publish(
        nickname: String, content: String, mediaJson: String, topic: String, fingerprint: String = ""
    ): ApiResult<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val params = mapOf(
                "nickname" to nickname,
                "content" to content,
                "media" to mediaJson,
                "fingerprint" to fingerprint,
                "topic" to topic
            )
            Net.postForm("post.php", params).use { resp ->
                // 站点成功后通常 302 跳转 index.php；OkHttp 默认跟随重定向。
                // 落地页为首页即视为成功。
                if (resp.isSuccessful || resp.isRedirect) ApiResult.Success(Unit)
                else ApiResult.Error("发布失败 (${resp.code})")
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    // ============== 圈子相关 ==============

    /** 获取圈子首页 → 推荐圈子列表。 */
    suspend fun getCircleList(): ApiResult<List<Circle>> = withContext(Dispatchers.IO) {
        runCatching {
            Net.circleGet("index.php").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                val list = CircleParser.parseCircleList(html)
                ApiResult.Success(list)
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 获取圈子详情（含帖子列表）。 */
    suspend fun getCircleDetail(circleId: String): ApiResult<CircleDetail> = withContext(Dispatchers.IO) {
        runCatching {
            Net.circleGet("index.php?p=circle&id=$circleId").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                val detail = CircleParser.parseCircleDetail(html, circleId)
                    ?: return@use ApiResult.Error("解析失败")
                ApiResult.Success(detail)
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    /** 获取圈子帖子详情。 */
    suspend fun getCirclePostDetail(postId: String, circleId: String = ""): ApiResult<CirclePostDetail> = withContext(Dispatchers.IO) {
        runCatching {
            Net.circleGet("index.php?p=post&id=$postId").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                val detail = CircleParser.parseCirclePostDetail(html, postId, circleId)
                    ?: return@use ApiResult.Error("解析失败")
                ApiResult.Success(detail)
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    // ============== 必吃榜 ==============

    suspend fun getBeachShopList(): ApiResult<List<BeachShop>> = withContext(Dispatchers.IO) {
        runCatching {
            Net.beachGet("").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                ApiResult.Success(BeachParser.parseShopList(html))
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }

    suspend fun getBeachShopDetail(shopId: String): ApiResult<BeachShopDetail> = withContext(Dispatchers.IO) {
        runCatching {
            Net.beachGet("shop/$shopId").use { resp ->
                if (!resp.isSuccessful) return@use ApiResult.Error("加载失败 (${resp.code})")
                val html = resp.body?.string() ?: ""
                val detail = BeachParser.parseShopDetail(html, shopId)
                    ?: return@use ApiResult.Error("解析失败")
                ApiResult.Success(detail)
            }
        }.getOrElse { ApiResult.Error(it.message ?: "网络错误") }
    }
}
