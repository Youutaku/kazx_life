package com.kazx.life.ui.detail

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.data.Comment
import com.kazx.life.databinding.ActivityDetailBinding
import com.kazx.life.net.AccentHelper
import com.kazx.life.repo.BbqRepository
import com.kazx.life.ui.PhotoViewerActivity
import com.kazx.life.ui.home.ImageGridAdapter
import kotlinx.coroutines.launch

/** 帖子详情：主体 + 评论列表 + 发评论 + 点赞 + 举报。 */
class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private val repo = BbqRepository()
    private val commentAdapter = CommentAdapter()
    private var postId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
        postId = intent.getStringExtra("id") ?: run { finish(); return }

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.commentList.layoutManager = LinearLayoutManager(this)
        binding.commentList.adapter = commentAdapter

        binding.btnSend.setOnClickListener { sendComment() }
        loadDetail()
    }

    override fun onResume() {
        super.onResume()
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
    }

    private fun loadDetail() {
        binding.loading.visibility = View.VISIBLE
        lifecycleScope.launch {
            when (val r = repo.getDetail(postId)) {
                is ApiResult.Success -> {
                    binding.loading.visibility = View.GONE
                    bindPost(r.data.post)
                    bindComments(r.data.comments)
                }
                is ApiResult.Error -> {
                    binding.loading.visibility = View.GONE
                    Snackbar.make(binding.root, r.message, Snackbar.LENGTH_INDEFINITE)
                        .setAction(R.string.retry) { loadDetail() }.show()
                }
            }
        }
    }

    private fun bindPost(post: com.kazx.life.data.Post) {
        val vb = binding.postCard
        val gd = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(safeColor(post.avatarColor)))
        }
        vb.avatar.background = gd
        vb.avatar.text = post.avatarText
        vb.nickname.text = post.nickname
        vb.badgeAdmin.visibility = if (post.isAdmin) View.VISIBLE else View.GONE
        vb.badgePinned.visibility = if (post.isPinned) View.VISIBLE else View.GONE
        vb.time.text = post.time
        vb.content.text = post.content
        vb.topic.visibility = if (!post.topic.isNullOrBlank()) View.VISIBLE else View.GONE
        vb.topic.text = post.topic ?: ""

        vb.imageSingle.visibility = View.GONE
        vb.imageGrid.visibility = View.GONE
        val openPhoto: (Int) -> Unit = { idx ->
            startActivity(
                Intent(this, PhotoViewerActivity::class.java)
                    .putStringArrayListExtra(
                        PhotoViewerActivity.EXTRA_IMAGES,
                        ArrayList(post.images)
                    )
                    .putExtra(PhotoViewerActivity.EXTRA_INDEX, idx)
            )
        }
        when {
            post.images.size == 1 -> {
                vb.imageSingle.visibility = View.VISIBLE
                Glide.with(this).load(post.images[0]).into(vb.imageSingle)
                vb.imageSingle.setOnClickListener { openPhoto(0) }
            }
            post.images.size > 1 -> {
                vb.imageGrid.visibility = View.VISIBLE
                vb.imageGrid.layoutManager = GridLayoutManager(this, 3)
                vb.imageGrid.adapter = ImageGridAdapter(post.images) { _, idx -> openPhoto(idx) }
            }
        }

        vb.likeCount.text = post.likeCount.toString()
        vb.commentCount.text = post.commentCount.toString()
        vb.iconLike.setColorFilter(
            if (post.liked) Color.parseColor("#EC407A") else Color.parseColor("#A39AA6")
        )
        // 详情页里卡片整体不再跳转
        vb.root.setOnClickListener(null)
        vb.btnLike.setOnClickListener {
            lifecycleScope.launch {
                when (val lr = repo.like(post.id)) {
                    is ApiResult.Success -> {
                        vb.likeCount.text = lr.data.toString()
                        vb.iconLike.setColorFilter(Color.parseColor("#EC407A"))
                    }
                    is ApiResult.Error -> snack(lr.message)
                }
            }
        }
        vb.btnComment.setOnClickListener {
            binding.commentInput.requestFocus()
        }
        vb.btnReport.setOnClickListener { showReportDialog(post.id) }
    }

    private fun bindComments(comments: List<Comment>) {
        commentAdapter.submit(comments)
        binding.emptyComment.visibility =
            if (comments.isEmpty()) View.VISIBLE else View.GONE
        binding.commentTitle.text = "评论 ${comments.size}"
    }

    private fun sendComment() {
        val text = binding.commentInput.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) {
            snack("请输入评论内容")
            return
        }
        binding.btnSend.isEnabled = false
        val nick = ""
        lifecycleScope.launch {
            when (val r = repo.comment(postId, nick, text)) {
                is ApiResult.Success -> {
                    binding.commentInput.text?.clear()
                    commentAdapter.add(
                        Comment(
                            id = "",
                            nickname = "匿名用户",
                            avatarColor = "#9C27B0",
                            avatarText = "匿",
                            content = text,
                            time = "刚刚",
                            isAdmin = false
                        )
                    )
                    binding.emptyComment.visibility = View.GONE
                    binding.commentTitle.text = "评论 ${commentAdapter.itemCount}"
                    snack(getString(R.string.ok))
                }
                is ApiResult.Error -> {
                    if (r.message.contains("登录")) {
                        snack("请先登录后再评论")
                    } else snack(r.message)
                }
            }
            binding.btnSend.isEnabled = true
        }
    }

    private fun showReportDialog(id: String) {
        val ctx = this
        val container = LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(50, 30, 50, 10)
        }
        val textPrimary = ctx.resources.getColor(R.color.text_primary, ctx.theme)
        val textHint = ctx.resources.getColor(R.color.text_hint, ctx.theme)
        val reason = EditText(ctx).apply {
            hint = "举报理由（如：违规广告、不雅内容）"
            setHintTextColor(textHint)
            setTextColor(textPrimary)
        }
        val detail = EditText(ctx).apply {
            hint = "补充说明（选填）"
            setHintTextColor(textHint)
            setTextColor(textPrimary)
        }
        container.addView(reason)
        container.addView(detail)
        AlertDialog.Builder(ctx)
            .setTitle(R.string.report_title)
            .setView(container)
            .setPositiveButton(R.string.btn_submit_report) { d, _ ->
                val r = reason.text.toString().trim().ifEmpty { "其他" }
                val de = detail.text.toString().trim()
                lifecycleScope.launch {
                    when (val res = repo.report(id, r, de)) {
                        is ApiResult.Success -> snack(getString(R.string.report_success))
                        is ApiResult.Error -> snack(res.message)
                    }
                }
                d.dismiss()
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }

    private fun snack(msg: String) =
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()

    private fun safeColor(c: String): String =
        if (c.matches(Regex("#[0-9A-Fa-f]{3,8}"))) c else "#9C27B0"
}
