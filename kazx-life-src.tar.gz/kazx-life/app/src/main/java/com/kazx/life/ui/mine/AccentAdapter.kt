package com.kazx.life.ui.mine

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kazx.life.databinding.ItemAccentBinding
import com.kazx.life.net.ThemeManager

/** 主题颜色选择列表适配器。 */
class AccentAdapter(
    private val selectedIndex: Int,
    private val onSelect: (Int) -> Unit
) : RecyclerView.Adapter<AccentAdapter.Holder>() {

    override fun getItemCount(): Int = ThemeManager.accents.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val vb = ItemAccentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(vb)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val accent = ThemeManager.accents[position]
        holder.bind(accent.name, accent.primary, position == selectedIndex)
        holder.itemView.setOnClickListener { onSelect(position) }
    }

    class Holder(private val vb: ItemAccentBinding) : RecyclerView.ViewHolder(vb.root) {
        fun bind(name: String, color: Int, selected: Boolean) {
            vb.name.text = name
            val gd = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(color)
            }
            vb.swatch.background = gd
            vb.check.visibility = if (selected) View.VISIBLE else View.GONE
        }
    }
}
