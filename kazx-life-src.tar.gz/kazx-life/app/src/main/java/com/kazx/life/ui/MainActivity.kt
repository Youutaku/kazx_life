package com.kazx.life.ui

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.commit
import com.google.android.material.navigation.NavigationBarView
import com.kazx.life.R
import com.kazx.life.databinding.ActivityMainBinding
import com.kazx.life.net.AccentHelper
import com.kazx.life.ui.beach.BeachFragment
import com.kazx.life.ui.circle.CircleFragment
import com.kazx.life.ui.home.HomeFragment
import com.kazx.life.ui.mine.SettingsActivity
import com.kazx.life.ui.publish.PublishActivity

/**
 * 主界面：底部导航切换【表白墙】/【圈子】/【必吃榜】，顶部工具栏+发帖悬浮按钮。
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var homeFragment: HomeFragment
    private lateinit var circleFragment: CircleFragment
    private lateinit var beachFragment: BeachFragment
    private var currentFragment: Fragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        // 动态应用主题颜色到 toolbar 渐变和 FAB
        applyAccent()

        if (savedInstanceState == null) {
            homeFragment = HomeFragment()
            circleFragment = CircleFragment()
            beachFragment = BeachFragment()
            supportFragmentManager.commit {
                add(R.id.nav_host, circleFragment, "circle").hide(circleFragment)
                add(R.id.nav_host, beachFragment, "beach").hide(beachFragment)
                add(R.id.nav_host, homeFragment, "home")
            }
            currentFragment = homeFragment
        } else {
            homeFragment = supportFragmentManager.findFragmentByTag("home") as? HomeFragment ?: HomeFragment()
            circleFragment = supportFragmentManager.findFragmentByTag("circle") as? CircleFragment ?: CircleFragment()
            beachFragment = supportFragmentManager.findFragmentByTag("beach") as? BeachFragment ?: BeachFragment()
            currentFragment = supportFragmentManager.primaryNavigationFragment ?: homeFragment
        }

        binding.fabPublish.setOnClickListener {
            startActivity(Intent(this, PublishActivity::class.java))
        }

        binding.bottomNav.setOnItemSelectedListener(onNavSelected)
        binding.bottomNav.selectedItemId = R.id.nav_home
    }

    private val onNavSelected = NavigationBarView.OnItemSelectedListener { item ->
        when (item.itemId) {
            R.id.nav_home -> {
                switchFragment(homeFragment)
                binding.toolbar.setTitle(R.string.home_title)
                binding.fabPublish.show()
                true
            }
            R.id.nav_circle -> {
                switchFragment(circleFragment)
                binding.toolbar.setTitle(R.string.circle_title)
                binding.fabPublish.hide()
                true
            }
            R.id.nav_beach -> {
                switchFragment(beachFragment)
                binding.toolbar.setTitle(R.string.beach_title)
                binding.fabPublish.hide()
                true
            }
            else -> false
        }
    }

    private fun switchFragment(target: Fragment) {
        if (currentFragment === target) return
        supportFragmentManager.commit {
            currentFragment?.let { hide(it) }
            show(target)
        }
        currentFragment = target
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_settings) {
            startActivity(Intent(this, SettingsActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onResume() {
        super.onResume()
        applyAccent()
    }

    private fun applyAccent() {
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
        binding.fabPublish.backgroundTintList =
            android.content.res.ColorStateList.valueOf(AccentHelper.secondaryColor())
    }
}
