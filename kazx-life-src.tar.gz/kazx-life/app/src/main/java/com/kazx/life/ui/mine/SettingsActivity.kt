package com.kazx.life.ui.mine

import android.content.Context
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.kazx.life.R
import com.kazx.life.databinding.ActivitySettingsBinding
import com.kazx.life.net.AccentHelper
import com.kazx.life.net.ThemeManager
import com.kazx.life.ui.about.AboutActivity
import java.io.File

/**
 * 设置页：
 *  - 外观：主题模式（跟随系统/浅色/深色）、字体大小（预留占位）
 *  - 数据与缓存：清除图片缓存、图片加载质量
 *  - 关于：关于 口中Life（含许可证列表）、访问官网
 */
class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    private val themes = intArrayOf(
        ThemeManager.MODE_FOLLOW_SYSTEM,
        ThemeManager.MODE_LIGHT,
        ThemeManager.MODE_DARK
    )
    private val themeLabels = arrayOf("跟随系统", "浅色模式", "深色模式")

    private val qualities = arrayOf("自动", "原图", "高清", "标清")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationIcon(R.drawable.ic_nav_home)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // toolbar 渐变背景动态应用选中颜色
        applyAccentToToolbar()

        refreshUi()
        binding.itemTheme.setOnClickListener { pickTheme() }
        binding.itemAccent.setOnClickListener { pickAccent() }
        binding.itemFont.setOnClickListener {
            Toast.makeText(this, "敬请期待", Toast.LENGTH_SHORT).show()
        }
        binding.itemClearCache.setOnClickListener { clearCache() }
        binding.itemImageQuality.setOnClickListener { pickQuality() }
        binding.itemAbout.setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }
        binding.itemVisitWeb.setOnClickListener {
            openUrl("https://kazx.top")
        }
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
        applyAccentToToolbar()
    }

    private fun applyAccentToToolbar() {
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
    }

    private fun refreshUi() {
        binding.themeValue.text = ThemeManager.label(ThemeManager.getMode())
        val accent = ThemeManager.getAccent()
        binding.accentValue.text = accent.name
        val gd = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(accent.primary)
        }
        binding.accentPreview.background = gd
        binding.cacheSize.text = readableCacheSize()
        binding.versionValue.text = versionName()
        binding.imageQualityValue.text = qualities[imageQualityIndex()]
    }

    private fun pickTheme() {
        val current = themes.indexOf(ThemeManager.getMode()).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle("选择主题模式")
            .setSingleChoiceItems(themeLabels, current) { d, which ->
                ThemeManager.setMode(themes[which])
                d.dismiss()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun pickAccent() {
        val current = ThemeManager.getAccentIndex()
        val dialogView = layoutInflater.inflate(R.layout.dialog_accent_picker, null)
        val recycler = dialogView.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.color_recycler)
        val dialog = AlertDialog.Builder(this)
            .setTitle("选择主题颜色")
            .setView(dialogView)
            .setNegativeButton("取消", null)
            .create()
        recycler.layoutManager = LinearLayoutManager(this)
        recycler.adapter = AccentAdapter(current) { index ->
            ThemeManager.setAccent(index)
            refreshUi()
            applyAccentToToolbar()
            dialog.dismiss()
        }
        dialog.show()
    }

    private fun clearCache() {
        val size = readableCacheSize()
        AlertDialog.Builder(this)
            .setTitle("清除图片缓存")
            .setMessage("当前缓存大小：$size。确认清除？")
            .setPositiveButton("清除") { d, _ ->
                deleteDir(cacheDir)
                deleteDir(externalCacheDir)
                runCatching {
                    val glideDir = File(cacheDir, "glide")
                    if (glideDir.exists()) deleteDir(glideDir)
                }
                refreshUi()
                Toast.makeText(this, "缓存已清除", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun pickQuality() {
        val current = imageQualityIndex()
        AlertDialog.Builder(this)
            .setTitle("图片加载质量")
            .setSingleChoiceItems(qualities, current) { d, which ->
                getSharedPreferences("kazx_prefs", Context.MODE_PRIVATE)
                    .edit().putInt("image_quality", which).apply()
                refreshUi()
                Toast.makeText(this, "已选择：${qualities[which]}", Toast.LENGTH_SHORT).show()
                d.dismiss()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun imageQualityIndex(): Int =
        getSharedPreferences("kazx_prefs", Context.MODE_PRIVATE).getInt("image_quality", 0)

    private fun readableCacheSize(): String {
        val dirs = listOfNotNull(cacheDir, externalCacheDir)
        var total = 0L
        for (d in dirs) total += sizeOf(d)
        return humanSize(total)
    }

    private fun sizeOf(f: File?): Long {
        if (f == null || !f.exists()) return 0L
        if (f.isFile) return f.length()
        var total = 0L
        f.listFiles()?.forEach { total += sizeOf(it) }
        return total
    }

    private fun deleteDir(f: File?) {
        if (f == null || !f.exists()) return
        if (f.isDirectory) f.listFiles()?.forEach { deleteDir(it) }
        runCatching { f.delete() }
    }

    private fun humanSize(bytes: Long): String = when {
        bytes < 1024 -> "${bytes}B"
        bytes < 1024 * 1024 -> String.format("%.1fKB", bytes / 1024.0)
        bytes < 1024 * 1024 * 1024 -> String.format("%.1fMB", bytes / 1024.0 / 1024.0)
        else -> String.format("%.2fGB", bytes / 1024.0 / 1024.0 / 1024.0)
    }

    private fun versionName(): String = "v" +
        packageManager.getPackageInfo(packageName, 0).versionName.orEmpty()

    private fun openUrl(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (_: Exception) {
            Toast.makeText(this, "未找到浏览器", Toast.LENGTH_SHORT).show()
        }
    }
}
