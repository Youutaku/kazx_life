package com.kazx.life.ui.circle

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.data.CircleDetail
import com.kazx.life.data.CirclePost
import com.kazx.life.databinding.ActivityCircleDetailBinding
import com.kazx.life.databinding.ItemCirclePostBinding
import com.kazx.life.repo.BbqRepository
import kotlinx.coroutines.launch

class CircleDetailActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ID = "circle_id"
        const val EXTRA_NAME = "circle_name"
    }

    private lateinit var binding: ActivityCircleDetailBinding
    private val repo = BbqRepository()
    private lateinit var circleId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCircleDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        circleId = intent.getStringExtra(EXTRA_ID) ?: ""
        val title = intent.getStringExtra(EXTRA_NAME) ?: getString(R.string.circle_detail)
        binding.toolbar.title = title
        binding.toolbar.setNavigationOnClickListener { finish() }

        load()
    }

    private fun load() {
        lifecycleScope.launch {
            when (val r = repo.getCircleDetail(circleId)) {
                is ApiResult.Success -> bind(r.data)
                is ApiResult.Error -> snack(r.message)
            }
        }
    }

    private fun bind(d: CircleDetail) {
        binding.name.text = d.name
        binding.desc.text = d.desc.ifEmpty { getString(R.string.empty) }
        binding.members.text = getString(R.string.circle_members_fmt, d.memberCount)
        binding.posts.text = getString(R.string.circle_posts_fmt, d.postCount)
        binding.owner.text = if (d.owner.isNotEmpty())
            getString(R.string.circle_owner_fmt, d.owner) else ""
        binding.owner.visibility = if (d.owner.isNotEmpty()) View.VISIBLE else View.GONE

        if (d.icon.isNotEmpty()) {
            Glide.with(this).load(d.icon).into(binding.icon)
        } else {
            val gd = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(colorForName(d.name))
            }
            binding.icon.setImageDrawable(gd)
            binding.icon.scaleType = android.widget.ImageView.ScaleType.CENTER
        }

        bindPosts(d.posts)
    }

    private fun bindPosts(posts: List<CirclePost>) {
        binding.emptyPosts.visibility = if (posts.isEmpty()) View.VISIBLE else View.GONE
        binding.postsContainer.removeAllViews()
        val inflater = LayoutInflater.from(this)
        posts.forEach { p ->
            val vb = ItemCirclePostBinding.inflate(inflater, binding.postsContainer, false)
            bindPostItem(vb, p)
            vb.root.setOnClickListener { openPost(p) }
            binding.postsContainer.addView(vb.root)
        }
    }

    private fun bindPostItem(vb: ItemCirclePostBinding, p: CirclePost) {
        val gd = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(colorForName(p.author.ifEmpty { p.avatarText }))
        }
        vb.avatar.background = gd
        vb.avatar.text = p.avatarText
        vb.title.text = p.title
        vb.summary.text = p.summary
        vb.summary.visibility = if (p.summary.isNotEmpty()) View.VISIBLE else View.GONE
        vb.author.text = p.author.ifEmpty { "匿名用户" }
        vb.time.text = p.time
        vb.comments.text = p.commentCount.toString()
    }

    private fun openPost(p: CirclePost) {
        startActivity(
            Intent(this, CirclePostDetailActivity::class.java)
                .putExtra(CirclePostDetailActivity.EXTRA_ID, p.id)
                .putExtra(CirclePostDetailActivity.EXTRA_CIRCLE_ID, p.circleId)
        )
    }

    private fun snack(msg: String) {
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
    }

    private fun colorForName(name: String): Int {
        val colors = arrayOf(
            "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
            "#009688", "#4CAF50", "#FF9800", "#F44336", "#E91E63"
        )
        val idx = (name.hashCode() and 0x7fffffff) % colors.size
        return Color.parseColor(colors[idx])
    }
}
