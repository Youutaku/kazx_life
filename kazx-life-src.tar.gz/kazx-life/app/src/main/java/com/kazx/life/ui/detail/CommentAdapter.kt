package com.kazx.life.ui.detail

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kazx.life.data.Comment
import com.kazx.life.databinding.ItemCommentBinding

/** 评论列表适配器。 */
class CommentAdapter : RecyclerView.Adapter<CommentAdapter.VH>() {

    private val items = mutableListOf<Comment>()

    fun submit(list: List<Comment>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    fun add(c: Comment) {
        items.add(c)
        notifyItemInserted(items.size - 1)
    }

    class VH(val binding: ItemCommentBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemCommentBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        val gd = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor(if (c.avatarColor.matches(Regex("#[0-9A-Fa-f]{3,8}"))) c.avatarColor else "#7E57C2"))
        }
        holder.binding.avatar.background = gd
        holder.binding.avatar.text = c.avatarText
        holder.binding.nickname.text = c.nickname
        holder.binding.badgeAdmin.visibility = if (c.isAdmin) View.VISIBLE else View.GONE
        holder.binding.content.text = c.content
        holder.binding.time.text = c.time
    }

    override fun getItemCount(): Int = items.size
}
