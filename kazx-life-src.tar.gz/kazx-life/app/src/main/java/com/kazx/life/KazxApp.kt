package com.kazx.life

import android.app.Application
import com.kazx.life.net.Net
import com.kazx.life.net.ThemeManager

/**
 * 应用入口，初始化全局网络组件与主题。
 */
class KazxApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Net.init(this)
        ThemeManager.init(this)
    }
}
