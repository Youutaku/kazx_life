package com.kazx.life.ui.circle

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.kazx.life.R
import com.kazx.life.data.ApiResult
import com.kazx.life.data.Circle
import com.kazx.life.databinding.FragmentCircleBinding
import com.kazx.life.databinding.ItemCircleBinding
import com.kazx.life.repo.BbqRepository
import kotlinx.coroutines.launch

/**
 * 圈子列表页：展示推荐圈子，点击进详情。
 */
class CircleFragment : Fragment() {

    private var _binding: FragmentCircleBinding? = null
    private val binding get() = _binding!!
    private val repo = BbqRepository()

    private val adapter = CircleAdapter { openDetail(it) }
    private val circles = mutableListOf<Circle>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentCircleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
        binding.swipe.setOnRefreshListener { refresh() }
        binding.stateRetry.setOnClickListener { refresh() }
        refresh()
    }

    private fun refresh() {
        binding.swipe.isRefreshing = true
        viewLifecycleOwner.lifecycleScope.launch {
            when (val r = repo.getCircleList()) {
                is ApiResult.Success -> {
                    circles.clear()
                    circles.addAll(r.data)
                    adapter.submit(circles)
                    showState(circles.isEmpty(), if (circles.isEmpty()) getString(R.string.empty) else "")
                }
                is ApiResult.Error -> {
                    if (circles.isEmpty()) showState(true, r.message)
                    else snack(r.message)
                }
            }
            binding.swipe.isRefreshing = false
        }
    }

    private fun openDetail(c: Circle) {
        startActivity(
            Intent(requireContext(), CircleDetailActivity::class.java)
                .putExtra(CircleDetailActivity.EXTRA_ID, c.id)
                .putExtra(CircleDetailActivity.EXTRA_NAME, c.name)
        )
    }

    private fun snack(msg: String) {
        Snackbar.make(binding.root, msg, Snackbar.LENGTH_SHORT).show()
    }

    private fun showState(show: Boolean, msg: String) {
        binding.stateView.visibility = if (show) View.VISIBLE else View.GONE
        binding.stateText.text = msg.ifEmpty { getString(R.string.empty) }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

class CircleAdapter(
    private val onClick: (Circle) -> Unit
) : RecyclerView.Adapter<CircleAdapter.Holder>() {

    private val items = mutableListOf<Circle>()

    fun submit(list: List<Circle>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val vb = ItemCircleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(vb)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(items[position])
    }

    inner class Holder(private val vb: ItemCircleBinding) : RecyclerView.ViewHolder(vb.root) {
        fun bind(c: Circle) {
            vb.name.text = c.name
            vb.desc.text = c.desc
            vb.members.text = vb.root.context.getString(R.string.circle_members_fmt, c.memberCount)
            vb.posts.text = vb.root.context.getString(R.string.circle_posts_fmt, c.postCount)

            if (c.icon.isNotEmpty()) {
                Glide.with(vb.root).load(c.icon).into(vb.icon)
            } else {
                // 用圈名首字生成彩色占位
                val gd = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colorForName(c.name))
                }
                vb.icon.setImageDrawable(gd)
                vb.icon.scaleType = android.widget.ImageView.ScaleType.CENTER
            }
            vb.root.setOnClickListener { onClick(c) }
        }

        private fun colorForName(name: String): Int {
            val colors = arrayOf(
                "#9C27B0", "#673AB7", "#3F51B5", "#2196F3",
                "#009688", "#4CAF50", "#FF9800", "#F44336", "#E91E63"
            )
            val idx = (name.hashCode() and 0x7fffffff) % colors.size
            return Color.parseColor(colors[idx])
        }
    }
}
