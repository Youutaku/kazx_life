package com.kazx.life.ui.about

import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kazx.life.R
import com.kazx.life.databinding.ActivityThanksBinding
import com.kazx.life.databinding.ItemDeveloperBinding
import com.kazx.life.databinding.ItemThanksBinding
import com.kazx.life.net.AccentHelper

/**
 * 鸣谢名单页：对应 about.kazx.top/thanks.html
 *  - 顶部"衷心感谢"标题
 *  - 三位网站开发者卡片（夏日之瓜、Youutaku、Accelerator）
 *  - 12 位特别鸣谢网格（快乐、南京晨跑大学、宋分题…）
 *  - 感谢语 + 页脚
 */
class ThanksActivity : AppCompatActivity() {

    data class Developer(val name: String, val subtitle: String?, val avatarRes: Int)
    data class ThanksItem(val name: String)

    private val developers = listOf(
        Developer("夏日之瓜", "(季节限定doge)", R.drawable.avatar_dev2),
        Developer("Youutaku", null, R.drawable.avatar_dev3),
        Developer("Accelerator", null, R.drawable.avatar_dev4)
    )

    private val thanksList = listOf(
        "快乐", "南京晨跑大学", "宋分题", "章鱼小丸子狂热爱好者",
        "口中万能墙", "德克萨斯做得到", "T–T", "逐梦海天",
        "风掠川暮", "新高一死宅", "zero", "等等......"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityThanksBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        binding.toolbar.background = gd
        binding.toolbar.setNavigationIcon(R.drawable.ic_nav_home)
        binding.toolbar.setNavigationOnClickListener { finish() }

        // 开发者卡片：直接动态插入（比另一个 RecyclerView 更轻）
        val inflater = LayoutInflater.from(this)
        for (dev in developers) {
            val vb = ItemDeveloperBinding.inflate(inflater, binding.devContainer, false)
            vb.name.text = dev.name
            vb.subtitle.text = dev.subtitle
            vb.subtitle.visibility = if (dev.subtitle.isNullOrBlank()) android.view.View.GONE else android.view.View.VISIBLE
            Glide.with(this).load(dev.avatarRes).circleCrop().into(vb.avatar)
            binding.devContainer.addView(vb.root)
        }

        // 特别鸣谢网格：3 列自适应
        binding.thanksGrid.layoutManager = GridLayoutManager(this, 3)
        binding.thanksGrid.adapter = ThanksAdapter(thanksList.map { ThanksItem(it) })
    }

    override fun onResume() {
        super.onResume()
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            AccentHelper.gradientColors()
        )
        findViewById<android.view.View>(R.id.toolbar).background = gd
    }
}

class ThanksAdapter(private val list: List<ThanksActivity.ThanksItem>) :
    RecyclerView.Adapter<ThanksAdapter.VH>() {

    class VH(val binding: ItemThanksBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemThanksBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.binding.name.text = list[position].name
    }

    override fun getItemCount(): Int = list.size
}
