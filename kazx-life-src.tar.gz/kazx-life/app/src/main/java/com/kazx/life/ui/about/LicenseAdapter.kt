package com.kazx.life.ui.about

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.kazx.life.databinding.ItemLicenseBinding

/** 开源许可证卡片适配器：点击展开/收起许可证全文。 */
class LicenseAdapter(
    private val list: List<LicenseItem>
) : RecyclerView.Adapter<LicenseAdapter.VH>() {

    private val expanded = BooleanArray(list.size) { false }

    class VH(val binding: ItemLicenseBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemLicenseBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = list[position]
        holder.binding.licenseName.text = item.name
        holder.binding.licenseVersion.text = item.version
        holder.binding.licenseDesc.text = "${item.author} — ${item.licenseType}"

        val show = expanded[position]
        holder.binding.licenseBody.text = item.notice +
            "\n\n许可证地址：${item.licenseUrl}"
        holder.binding.licenseBody.visibility = if (show) View.VISIBLE else View.GONE

        holder.binding.root.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos in list.indices) {
                expanded[pos] = !expanded[pos]
                notifyItemChanged(pos)
            }
        }
    }

    override fun getItemCount(): Int = list.size
}
