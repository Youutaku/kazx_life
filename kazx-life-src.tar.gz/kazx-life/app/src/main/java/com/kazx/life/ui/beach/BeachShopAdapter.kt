package com.kazx.life.ui.beach

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.kazx.life.R
import com.kazx.life.data.BeachShop
import com.kazx.life.databinding.ItemBeachShopBinding
import kotlin.math.roundToInt

/** 必吃榜店铺列表适配器。 */
class BeachShopAdapter(
    private val onClick: (BeachShop) -> Unit
) : RecyclerView.Adapter<BeachShopAdapter.Holder>() {

    private var items = emptyList<BeachShop>()

    @SuppressLint("NotifyDataSetChanged")
    fun set(list: List<BeachShop>) {
        items = list
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int = items.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        val vb = ItemBeachShopBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return Holder(vb)
    }

    override fun onBindViewHolder(holder: Holder, position: Int) {
        holder.bind(items[position])
    }

    inner class Holder(private val vb: ItemBeachShopBinding) : RecyclerView.ViewHolder(vb.root) {
        fun bind(shop: BeachShop) {
            vb.name.text = shop.name
            vb.badgeClaimed.visibility = if (shop.claimed) View.VISIBLE else View.GONE

            // 评分
            val rating = shop.rating.coerceIn(0f, 5f)
            if (shop.rating < 0) {
                vb.stars.text = "☆☆☆☆☆"
                vb.ratingText.text = vb.root.context.getString(R.string.beach_rating_pending)
            } else {
                val filled = rating.roundToInt().coerceIn(0, 5)
                vb.stars.text = "★".repeat(filled) + "☆".repeat(5 - filled)
                vb.ratingText.text = vb.root.context.getString(
                    R.string.beach_rating_fmt, rating, shop.rateCount
                )
            }

            vb.address.text = shop.address.ifEmpty {
                vb.root.context.getString(R.string.beach_address_hint)
            }

            // 封面：优先图片，无图显示占位字符
            if (shop.cover.isNotEmpty()) {
                vb.coverText.visibility = View.GONE
                vb.cover.visibility = View.VISIBLE
                Glide.with(vb.cover.context)
                    .load(shop.cover)
                    .placeholder(R.drawable.bg_chip)
                    .centerCrop()
                    .into(vb.cover)
            } else {
                vb.cover.visibility = View.GONE
                vb.coverText.visibility = View.VISIBLE
                vb.coverText.text = shop.coverText.ifEmpty {
                    shop.name.firstOrNull()?.toString() ?: " "
                }
            }

            vb.root.setOnClickListener { onClick(shop) }
        }
    }
}
