# WebView/解析类应用无需混淆，保持默认关闭。
# 如启用 minify，请保留：
# -keep class org.jsoup.** { *; }
# -keep class okhttp3.** { *; }
# -keep class com.bumptech.glide.** { *; }
